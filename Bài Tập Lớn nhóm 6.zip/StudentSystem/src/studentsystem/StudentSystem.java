
package studentsystem;

public class StudentSystem {


    public static void main(String[] args) {
        // TODO code application logic here
       SFStudent st = new SFStudent();
       st.show();
    }
    
}
