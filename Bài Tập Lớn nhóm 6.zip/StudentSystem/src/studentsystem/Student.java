
package studentsystem;

public class Student {
    private String ID;
    private String name;
    private int age;
    private String GioiTinh ;
    private String Lop;
    private String Diachi;

    public Student(String ID, String name, int age, String GioiTinh, String Lop, String Diachi) {
        this.ID = ID;
        this.name = name;
        this.age = age;
        this.GioiTinh = GioiTinh;
        this.Lop = Lop;
        this.Diachi = Diachi;

    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getGioiTinh() {
        return GioiTinh;
    }

    public void setGioiTinh(String GioiTinh) {
        this.GioiTinh = GioiTinh;
    }

    public String getLop() {
        return Lop;
    }

    public void setLop(String Lop) {
        this.Lop = Lop;
    }

    public String getDiachi() {
        return Diachi;
    }

    public void setDiachi(String Diachi) {
        this.Diachi = Diachi;
    }
    
    
}