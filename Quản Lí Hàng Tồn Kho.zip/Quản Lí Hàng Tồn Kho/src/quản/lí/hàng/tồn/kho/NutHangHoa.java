
package quản.lí.hàng.tồn.kho;

public class NutHangHoa {
    // Thuộc tính dữ liệu
    private String maHang;
    private String tenMatHang;
    private String donViTinh;
    private int soLuongTonKho;
    private double giaBan;

    // Con trỏ liên kết kép
    NutHangHoa prev; 
    NutHangHoa next; 

    // Constructor
    public NutHangHoa(String maHang, String tenMatHang, String donViTinh, 
                      int soLuongTonKho, double giaBan) {
        this.maHang = maHang;
        this.tenMatHang = tenMatHang;
        this.donViTinh = donViTinh;
        this.soLuongTonKho = soLuongTonKho;
        this.giaBan = giaBan;
        this.prev = null;
        this.next = null;
    }

    public void setMaHang(String maHang) {
        this.maHang = maHang;
    }

    public void setTenMatHang(String tenMatHang) {
        this.tenMatHang = tenMatHang;
    }

    public void setDonViTinh(String donViTinh) {
        this.donViTinh = donViTinh;
    }

    public void setSoLuongTonKho(int soLuongTonKho) {
        this.soLuongTonKho = soLuongTonKho;
    }

    public void setGiaBan(double giaBan) {
        this.giaBan = giaBan;
    }

    public void setPrev(quản.lí.hàng.tồn.kho.NutHangHoa prev) {
        this.prev = prev;
    }

    public void setNext(quản.lí.hàng.tồn.kho.NutHangHoa next) {
        this.next = next;
    }
    

    // Getters 
    public int getSoLuongTonKho() {
        return soLuongTonKho;
    }

    public double getGiaBan() {
        return giaBan;
    }

    public String getTenMatHang() {
        return tenMatHang;
    }

    // Phương thức hiển thị
    public void hienThi() {
        System.out.printf("| Mã: %-8s | Tên: %-15s | ĐVT: %-8s | Tồn kho: %-4d | Giá bán: %-10.0f |\n",
                          maHang, tenMatHang, donViTinh, soLuongTonKho, giaBan);
    }
}
