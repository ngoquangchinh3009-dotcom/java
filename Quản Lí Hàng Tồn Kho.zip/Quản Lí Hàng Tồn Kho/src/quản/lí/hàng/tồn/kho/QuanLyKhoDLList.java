
package quản.lí.hàng.tồn.kho;

import java.util.*;

public class QuanLyKhoDLList {
    private NutHangHoa head;
    private NutHangHoa tail;

    public QuanLyKhoDLList() {
        this.head = null;
        this.tail = null;
    }

    // --- Hàm tiện ích chung ---
    
    // Hàm kiểm tra Số hoàn hảo (Yêu cầu 23.3)
    private boolean laSoHoanHao(int n) {
        if (n <= 1) return false;
        int sum = 1;
        for (int i = 2; i * i <= n; i++) {
            if (n % i == 0) {
                sum += i;
                if (i * i != n) {
                    sum += n / i;
                }
            }
        }
        return sum == n; // Tính toán các số hoàn hảo [1-3]
    }
    
    // Hiển thị danh sách 
    public void hienThiDanhSach() {
        if (head == null) {
            System.out.println("Danh sách kho hàng rỗng.");
            return;
        }
        System.out.println("\n--- DANH SÁCH HÀNG TỒN KHO ---");
        NutHangHoa current = head;
        while (current != null) {
            current.hienThi();
            current = current.next;
        }
        System.out.println("-------------------------------");
    }

    // --- Các phương thức thực hiện yêu cầu đề tài (23.1 - 23.6) ---

    // 23.1. Thêm mặt hàng tại vị trí tùy chọn [2-5]
    public void themMatHangTaiViTri(NutHangHoa nutMoi, int viTri) {
        if (viTri <= 0) {
            System.out.println("Vị trí không hợp lệ. Vị trí phải là số dương.");
            return;
        }
        
        if (head == null || viTri == 1) { // Trường hợp rỗng hoặc thêm đầu
            if (head == null) {
                head = tail = nutMoi;
            } else {
                nutMoi.next = head;
                head.prev = nutMoi;
                head = nutMoi;
            }
            return;
        }

        NutHangHoa current = head;
        int count = 1;
        while (current != null && count < viTri) {
            current = current.next;
            count++;
        }

        if (current == null) { // Thêm cuối
            tail.next = nutMoi;
            nutMoi.prev = tail;
            tail = nutMoi;
        } else { // Thêm giữa
            nutMoi.prev = current.prev;
            nutMoi.next = current;
            current.prev.next = nutMoi;
            current.prev = nutMoi;
        }
        System.out.println("Đã thêm mặt hàng thành công tại vị trí " + (current == null ? "cuối" : viTri));
    }
    
    // 23.2. Xóa tất cả các mặt hàng có Số lượng tồn kho bằng 0 [6-8]
    public int xoaMatHangTonKhoBangKhong() {
        NutHangHoa current = head;
        int countDeleted = 0;
        
        while (current != null) {
            if (current.getSoLuongTonKho() == 0) {
                countDeleted++;
                
                // Xử lý liên kết
                if (current == head) {
                    head = current.next;
                    if (head != null) head.prev = null;
                } else if (current == tail) {
                    tail = current.prev;
                    if (tail != null) tail.next = null;
                } else {
                    current.prev.next = current.next;
                    current.next.prev = current.prev;
                }
                
                // Di chuyển con trỏ kiểm tra
                NutHangHoa nextNode = current.next;
                if (head == null) tail = null; 
                current = nextNode; 
            } else {
                current = current.next;
            }
        }
        return countDeleted;
    }
    
    // 23.3. Đếm hàng hóa có Giá bán > P và kiểm tra số hoàn hảo
    public void demVaKiemTraGiaBan(double p) {
        NutHangHoa current = head;
        int count = 0;
        while (current != null) {
            if (current.getGiaBan() > p) {
                count++;
            }
            current = current.next;
        }

        System.out.printf("Số lượng mặt hàng có Giá bán > %.0f là: %d\n", p, count);
        if (laSoHoanHao(count)) {
            System.out.println("=> Số lượng này (" + count + ") là **SỐ HOÀN HẢO** [1-3].");
        } else {
            System.out.println("=> Số lượng này (" + count + ") KHÔNG phải là số hoàn hảo.");
        }
    }
    
    // 23.4. Tính TBC Số lượng tồn kho cho các mặt hàng có Giá bán là số lẻ dương [1, 9]
    public void tinhTBCSoLuongTonKhoTheoGiaLe() {
        NutHangHoa current = head;
        int sumQuantity = 0;
        int count = 0;

        while (current != null) {
            double giaBan = current.getGiaBan();
            // Kiểm tra Giá bán là số lẻ dương (giả định giá là số nguyên khi kiểm tra chẵn lẻ)
            if (giaBan > 0 && giaBan == (int)giaBan && ((int)giaBan % 2 != 0)) {
                sumQuantity += current.getSoLuongTonKho();
                count++;
            }
            current = current.next;
        }

        if (count == 0) {
            System.out.println("Không có mặt hàng nào thỏa mãn điều kiện (Giá bán là số lẻ dương).");
        } else {
            double tbc = (double) sumQuantity / count;
            System.out.printf("Trung bình cộng số lượng tồn kho của các mặt hàng thỏa mãn điều kiện là: **%.2f**\n", tbc);
        }
    }

    // 23.5. Sắp xếp danh sách theo Giá bán giảm dần và Tên mặt hàng tăng dần [16.6, 19.6]
    public void sapXepTheoGiaVaTen() {
        if (head == null) return;
        
        // Bước 1: Thu thập tất cả Node vào List tạm thời
        List<NutHangHoa> list = new ArrayList<>();
        NutHangHoa current = head;
        while (current != null) {
            list.add(current);
            current = current.next;
        }
        
        // Bước 2: Sắp xếp List tạm thời (Comparator phức hợp)
        Collections.sort(list, (NutHangHoa h1, NutHangHoa h2) -> {
            // Giá bán GIẢM DẦN (h2 so với h1)
            if (h1.getGiaBan() != h2.getGiaBan()) {
                return Double.compare(h2.getGiaBan(), h1.getGiaBan());
            }
            // Tên mặt hàng TĂNG DẦN
            return h1.getTenMatHang().compareToIgnoreCase(h2.getTenMatHang());
        });
        
        // Bước 3: Xây dựng lại DLL (Tái liên kết các node đã sắp xếp)
        if (list.isEmpty()) { head = tail = null; return; }
        
        head = list.get(0);
        head.prev = null;
        NutHangHoa temp = head;
        
        for (int i = 1; i < list.size(); i++) {
            NutHangHoa nextNode = list.get(i);
            temp.next = nextNode;
            nextNode.prev = temp;
            temp = nextNode;
        }
        tail = temp;
        tail.next = null;
        
        System.out.println("Đã sắp xếp danh sách theo tiêu chí kép thành công.");
    }
    
    // 23.6. Kiểm tra 3 mặt hàng liên tiếp có Số lượng tồn kho tạo thành Cấp số cộng [2, 3, 6]
    public void kiemTraCapSoCong() {
        if (head == null || head.next == null || head.next.next == null) {
            System.out.println("Danh sách phải có ít nhất 3 mặt hàng để kiểm tra cấp số cộng.");
            return;
        }
        
        NutHangHoa current = head;
        boolean found = false;
        
        while (current != null && current.next != null && current.next.next != null) {
            int q1 = current.getSoLuongTonKho();
            int q2 = current.next.getSoLuongTonKho();
            int q3 = current.next.next.getSoLuongTonKho();
            
            // Điều kiện cấp số cộng: 2*q2 = q1 + q3
            if (2 * q2 == q1 + q3) {
                System.out.println("\n=> Đã tìm thấy 3 mặt hàng liên tiếp tạo thành cấp số cộng (dựa trên Tồn kho):");
                current.hienThi();
                current.next.hienThi();
                current.next.next.hienThi();
                found = true;
                break; // Tìm thấy 1 bộ là đủ (tùy theo yêu cầu đề bài, ở đây chỉ cần tìm thấy)
            }
            current = current.next;
        }
        
        if (!found) {
            System.out.println("Không tìm thấy 3 mặt hàng liên tiếp nào có số lượng tồn kho tạo thành cấp số cộng.");
        }
    }
}
