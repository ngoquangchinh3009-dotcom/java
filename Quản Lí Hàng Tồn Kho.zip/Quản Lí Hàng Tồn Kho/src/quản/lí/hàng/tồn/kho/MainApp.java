
package quản.lí.hàng.tồn.kho;

import java.util.InputMismatchException;
import java.util.Scanner;
public class MainApp {
    
    private static void khoiTaoDuLieu(QuanLyKhoDLList manager) {
        // Thêm dữ liệu mẫu (sử dụng themMatHangTaiViTri để đảm bảo DLL được xây dựng đúng)
        manager.themMatHangTaiViTri(new NutHangHoa("MH001", "Laptop", "Cái", 15, 25000000), 1);
        manager.themMatHangTaiViTri(new NutHangHoa("MH002", "Chuột", "Cái", 0, 150000), 2);
        manager.themMatHangTaiViTri(new NutHangHoa("MH003", "Bàn phím", "Cái", 5, 500000), 3);
        manager.themMatHangTaiViTri(new NutHangHoa("MH004", "USB", "Chiếc", 20, 100000), 4);
        manager.themMatHangTaiViTri(new NutHangHoa("MH005", "Màn hình", "Cái", 0, 5000000), 5);
        manager.themMatHangTaiViTri(new NutHangHoa("MH006", "Giấy A4", "Ram", 10, 80000), 6);
        manager.themMatHangTaiViTri(new NutHangHoa("MH007", "Máy in", "Cái", 10, 1500000), 7);
        manager.themMatHangTaiViTri(new NutHangHoa("MH008", "Tablet", "Cái", 15, 12000000), 8); 
        // Dữ liệu cho CSC (5, 10, 15)
        manager.themMatHangTaiViTri(new NutHangHoa("MH009", "Cáp", "Sợi", 5, 20000), 9);
        manager.themMatHangTaiViTri(new NutHangHoa("MH010", "Sạc", "Cục", 10, 100000), 10);
        manager.themMatHangTaiViTri(new NutHangHoa("MH011", "Ổ cứng", "Cái", 15, 800000), 11);
    }

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            QuanLyKhoDLList manager = new QuanLyKhoDLList();
            
            khoiTaoDuLieu(manager);
            System.out.println("Đã khởi tạo danh sách hàng tồn kho bằng Danh sách Liên kết Kép.");
            
            int luaChon;
            do {
                System.out.println("\n========== MENU QUẢN LÝ HÀNG TỒN KHO (DLL) ==========");
                System.out.println("1. Hiển thị danh sách");
                System.out.println("2. Thêm mặt hàng mới tại vị trí tùy chọn (Yêu cầu 23.1) [2-5]");
                System.out.println("3. Xóa các mặt hàng có tồn kho = 0 (Yêu cầu 23.2) [6-8]");
                System.out.println("4. Đếm mặt hàng có Giá bán > P & Kiểm tra Số hoàn hảo (Yêu cầu 23.3) [1-3]");
                System.out.println("5. Tính TBC Tồn kho theo Giá bán Lẻ Dương (Yêu cầu 23.4) [1, 9]");
                System.out.println("6. Sắp xếp theo Giá bán G.Dần và Tên T.Dần (Yêu cầu 23.5) [16.6, 19.6]");
                System.out.println("7. Kiểm tra 3 mặt hàng liên tiếp tạo Cấp số cộng (Yêu cầu 23.6) [2, 3, 6]");
                System.out.println("0. Thoát chương trình");
                System.out.print("Vui lòng chọn chức năng: ");
                
                if (scanner.hasNextInt()) {
                    luaChon = scanner.nextInt();
                    scanner.nextLine();
                } else {
                    System.out.println("Lựa chọn không hợp lệ. Vui lòng nhập số.");
                    scanner.nextLine();
                    luaChon = -1;
                }
                
                try {
                    switch (luaChon) {
                        case 1 -> manager.hienThiDanhSach();
                        case 2 -> {
                            System.out.println("--- Nhập thông tin mặt hàng mới ---");
                            System.out.print("Mã Hàng: "); String ma = scanner.nextLine();
                            System.out.print("Tên Mặt hàng: "); String ten = scanner.nextLine();
                            System.out.print("Đơn vị tính: "); String dvt = scanner.nextLine();
                            System.out.print("Số lượng tồn kho: "); int sl = scanner.nextInt();
                            System.out.print("Giá bán: "); double gia = scanner.nextDouble();
                            System.out.print("Vị trí muốn thêm (1 là đầu): "); int viTri = scanner.nextInt();
                            scanner.nextLine();
                            manager.themMatHangTaiViTri(new NutHangHoa(ma, ten, dvt, sl, gia), viTri);
                        }
                            
                        case 3 -> {
                            int deleted = manager.xoaMatHangTonKhoBangKhong();
                            System.out.println("=> Đã xóa thành công " + deleted + " mặt hàng có tồn kho bằng 0.");
                        }
                            
                        case 4 -> {
                            System.out.print("Nhập mức giá P để so sánh: ");
                            double p = scanner.nextDouble();
                            manager.demVaKiemTraGiaBan(p);
                        }
                            
                        case 5 -> manager.tinhTBCSoLuongTonKhoTheoGiaLe();
                            
                        case 6 -> {
                            manager.sapXepTheoGiaVaTen();
                            manager.hienThiDanhSach();
                        }
                            
                        case 7 -> manager.kiemTraCapSoCong();
                            
                        case 0 -> System.out.println("Chương trình kết thúc. Tạm biệt!");
                            
                        default -> System.out.println("Lựa chọn không hợp lệ, vui lòng thử lại.");
                    }
                } catch (InputMismatchException e) {
                    System.out.println("Lỗi nhập liệu. Vui lòng nhập đúng kiểu dữ liệu (số nguyên, số thực).");
                    scanner.nextLine();
                }
            } while (luaChon != 0);
        }
    }
}
