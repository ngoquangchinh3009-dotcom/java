
package Model;


public class HocSinh {
    private int ID;
    private String Mahs,Tenhs,Gt,Date,Diachi,Dantoc;
    private int Lop;
    
    public HocSinh(){
    }
    public HocSinh(String Mahs, String Tenhs, String Gt, String Date, String Diachi, String Dantoc, int Lop) {
        this.Mahs = Mahs;
        this.Tenhs = Tenhs;
        this.Gt = Gt;
        this.Date = Date;
        this.Diachi = Diachi;
        this.Dantoc = Dantoc;
        this.Lop = Lop;
    }

    public HocSinh(int ID, String Mahs, String Tenhs, String Gt, String Date, String Diachi, String Dantoc, int Lop) {
        this.ID = ID;
        this.Mahs = Mahs;
        this.Tenhs = Tenhs;
        this.Gt = Gt;
        this.Date = Date;
        this.Diachi = Diachi;
        this.Dantoc = Dantoc;
        this.Lop = Lop;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getMahs() {
        return Mahs;
    }

    public void setMahs(String Mahs) {
        this.Mahs = Mahs;
    }

    public String getTenhs() {
        return Tenhs;
    }

    public void setTenhs(String Tenhs) {
        this.Tenhs = Tenhs;
    }

    public String getGt() {
        return Gt;
    }

    public void setGt(String Gt) {
        this.Gt = Gt;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String Date) {
        this.Date = Date;
    }

    public String getDiachi() {
        return Diachi;
    }

    public void setDiachi(String Diachi) {
        this.Diachi = Diachi;
    }

    public String getDantoc() {
        return Dantoc;
    }

    public void setDantoc(String Dantoc) {
        this.Dantoc = Dantoc;
    }

    public int getLop() {
        return Lop;
    }

    public void setLop(int Lop) {
        this.Lop = Lop;
    }
    
    
}
    