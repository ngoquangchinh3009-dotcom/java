
package Controler;

public class DAOhs {
    
    public DAOhs() {
s        private connection conn;     
}
    
}
